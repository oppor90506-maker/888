# Endcord Orbs Overlay

本插件為 Endcord Desktop Mod 使用的本機顯示插件。

## 功能
- Discord 視窗內的可拖曳 Orbs 懸浮球
- 拖曳後吸附至視窗左側或右側
- 點擊懸浮球開啟編輯面板
- 自訂顯示數字、圖示、顏色
- 發光與淡入效果
- 保存位置與設定
- 不讀取、不修改、不提交 Discord 真實 Orbs 餘額

## 安裝（原始碼方式）
1. 將 `orbsOverlay` 資料夾放入 Endcord 原始碼的 `src/plugins/`。
2. 確認 `src/plugins/index.ts` 的插件自動掃描規則會載入該資料夾（Endcord 官方文件說明插件目錄為 `src/plugins`）。
3. 在 Endcord 原始碼根目錄執行：
   ```bash
   pnpm lint
   pnpm testTsc
   pnpm build
   pnpm inject
   ```
4. 重新載入 Discord（Ctrl+R），到 Endcord 設定的 Plugins 頁面啟用 `OrbsOverlay`。

## 注意
- 此版本使用 Endcord/Vencord 相容的 `definePlugin()` 與 `definePluginSettings()` API。
- 插件作者欄位使用本機佔位作者資訊；若要提交上游，請換成自己的作者資料並遵循 Endcord 的五種語言翻譯規範。
- Endcord API 可能隨版本變動；請以你安裝的 Endcord 分支中的 `src/utils/types.ts` 和 `src/api/Settings.ts` 為準。
